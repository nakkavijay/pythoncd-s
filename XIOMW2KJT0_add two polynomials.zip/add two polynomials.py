'''
6x^3 + 10x^2 + 5 -> polynomial -1
4x^2 + 2x + 1 -> polynomial - 2

6x^3 + 14x^2 + 2x + 6   --> final polynomial 


1. breaking down parts
first step reading inputs
addintion 


1.Reading inputs

def read_inputs_create_dictionary():
    n = int(input())   #The first line contains a single integer M. 
    polynomial_dict = {}
    for i in range(n):
        #two integers seperate spaces 
        power_coefficient = input().split()
        power = int(power_coefficient[0])
        coefficient = int(power_coefficient[1])
        polynomial_dict[power] = coefficient
    return polynomial_dict 

polynomial_1 = read_inputs_create_dictionary()
polynomial_2 = read_inputs_create_dictionary()

print(polynomial_1)
print(polynomial_2)



2.Adding polynomials

keys,values uses to adding polynomials
based on keys add polynoomials

'''  
'''
combined polynomial 
example
6x^3 + 10x^2 + 5
4x^2 + 2x + 1

6x^3 + (10 + 4 )x^2 + 2x + (5 + 1)

ex 4x^2 + (-2)x + 3
 
 
 6x^3 + -1x^2 + 2x + 6 + output


def adding_polynomials(polynomial_1,polynomial_2):
    combined_polynomial = polynomial_1
    print(combined_polynomial)
    for power in polynomial_2:
        if power in combined_polynomial:
            combined_polynomial[power] += polynomial_2[power]  
        else:
            combined_polynomial[power] = polynomial_2[power]
        print(power, combined_polynomial)
    return combined_polynomial
    
    
    
polynomial_1 = read_inputs_create_dictionary()
polynomial_2 = read_inputs_create_dictionary()


adding_polynomials(polynomial_1,polynomial_2)



3. printing the output

'''
# first process test inputs
def read_inputs_create_dictionary():
    n = int(input())   #The first line contains a single integer M. 
    polynomial_dict = {}
    for i in range(n):
        #two integers seperate spaces 
        power_coefficient = input().split()
        power = int(power_coefficient[0])
        coefficient = int(power_coefficient[1])
        polynomial_dict[power] = coefficient
    return polynomial_dict 
# adding polynimials
def adding_polynomials(polynomial_1,polynomial_2):
    combined_polynomial = polynomial_1
    
    for power in polynomial_2:
        if power in combined_polynomial:
            combined_polynomial[power] += polynomial_2[power]  
        else:
            combined_polynomial[power] = polynomial_2[power]
        
    return combined_polynomial

#printing output   
'''def print_output(combined_polynomial):
    #decreasing order we use sorted
    # revers we 
    powers = sorted(combined_polynomial.keys(), reverse = True)
    # print(powers)
    #output decreasing or der  [3, 2, 1, 0]
    result = ""
    for power in powers:
        result += str(combined_polynomial[power])
        if power != 0:
            result += 'x^' + str(power)
        result += ' + '   '''
    # print(result)    
    # output is 6x^3 + 14x^2 + 2x^1 + 6x^0 + 
    #print(result) 6x^3 + 14x^2 + 2x^1 + 6 + 
'''def print_output(combined_polynomial):
    powers = sorted(combined_polynomial.keys(), reverse = True)
    result = ""
    for power in powers:
        result += str(combined_polynomial[power])
        if power == 1:
            result += 'x'
        elif power >= 1:
            result += 'x^' + str(power)
        result += ' + '
    # print(result)   output   6x^3 + 14x^2 + 2x + 6 +  '''
    
    
'''def print_output(combined_polynomial):
    powers = sorted(combined_polynomial.keys(), reverse = True)
    result = ""
    for power in powers:
        coefficient = combined_polynomial[power]
        if coefficient ==0:
            continue
        result += str(coefficient)
       
        if power == 1:
            result += 'x'
        elif power >= 1:
            result += 'x^' + str(power)
        result += ' + '
    print(result)   
    print(result)     6x^3 + 14x^2 + 2x + 6 + '''
def print_output(combined_polynomial):
    powers = sorted(combined_polynomial.keys(), reverse = True)
    result = ""
    for power in powers:
        coefficient = combined_polynomial[power]
        if coefficient ==0:
            continue  #it will be direct go to next items in the powers 
        if power != max(powers):
            if coefficient < 0:
                result += ' - '
            else:
                result += ' + '
              # abs is function  
            coefficient = abs(coefficient)
        if abs(coefficient ) == 1 and power ==0:
            result += str(abs(coefficient))
        elif abs(coefficient) != 1:
            result += str(coefficient)
        if power == 1:
            result += 'x'
        elif power > 1:
            result += 'x^' + str(power)
    if result == "":
        print("0")
    else:
        print(result)
   
polynomial_1 = read_inputs_create_dictionary()
polynomial_2 = read_inputs_create_dictionary()


combined_polynomial = adding_polynomials(polynomial_1,polynomial_2)
print_output(combined_polynomial)