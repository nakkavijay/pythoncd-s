string1 = str(input())
string2 = str(input())

def checkingStrings(strings1, strings2):
    answer = ''
    len1, len2 = len(strings1) , len(strings2)
    for i in range(len1):
        match = ""
        for j in range(len2):
            if (i + j < len1 and strings1[i + j] == strings2[j]):
                match += strings2[j]
            else:
                if (len(match) > 1):
                    answer = match
                    match = ''
    if answer == "":
        return "No overlapping"
    else:
        return answer
    
print(checkingStrings(string1,string2))